# KSelectHub.com Planning: Sitemap, Phase 1 Scope & Story Flow (Updated)

This document outlines the final aligned conceptual planning for the new B2B marketing site targeting US retail buyers. It has been updated to reflect security, legal, conversion rate, and lean development alignment.

---

## 1. Aligned Sitemap Structure

To maintain a lean footprint in Phase 1, we avoid unnecessary page sprawl. Instead of separate pages for "How It Works" or "Why K Select", we keep them as dynamic anchor sections on the Homepage. This maximizes conversion by keeping the user narrative continuous.

```mermaid
graph TD
    Root["/ (Auto-redirect via Middleware)"] --> EN["/en (English - Primary)"]
    Root --> KO["/ko (Korean - Secondary)"]
    
    subgraph English Route Group
        EN --> EN_Home["/en (Homepage with Anchors: #program, #how-it-works, #why-kselect)"]
        EN --> EN_Products["/en/products (Curated Catalog Showroom)"]
        EN --> EN_Apply["/en/apply (Retailer Application Form)"]
        EN --> EN_Contact["/en/contact (General Inquiry)"]
        EN_Apply --> EN_Success["/en/apply/success (Confirmation)"]
    end
    
    subgraph Korean Route Group
        KO --> KO_Home["/ko (Homepage with Anchors: #program, #how-it-works, #why-kselect)"]
        KO --> KO_Products["/ko/products (Curated Catalog Showroom)"]
        KO --> KO_Apply["/ko/apply (Retailer Application Form)"]
        KO --> KO_Contact["/ko/contact (General Inquiry)"]
        KO_Apply --> KO_Success["/ko/apply/success (Confirmation)"]
    end
```

### Page Breakdown & Navigation Menus
*   **Header Navigation**:
    *   `The Program` (Anchor to `#program`)
    *   `How It Works` (Anchor to `#how-it-works`)
    *   `Products` (Navigates to `/products`)
    *   `Apply Now` (Button navigating to `/apply`)
    *   `Retailer Login` (Direct external link to transactional `portal.kselecthub.com`)

---

## 2. Phase 1 Feature Scope & Architecture

Phase 1 focuses on building a highly converting, secure, bilingual frontend connected to Supabase for lead collection and public product display.

### A. Secure Product Showcase Layer
To prevent leaking sensitive wholesale pricing, supplier costs, margins, or private inventory data, the marketing site will **never** query the raw `products` master table directly.
*   **Database View Layer**: A database view `public_showroom_products` will be created in Supabase.
*   **Column Projection**: The view only exposes public attributes: `id`, `name`, `brand`, `category`, `description`, `key_benefits`, `image_urls`, and `is_public_marketing`.
*   **Read-Only Access**: The marketing site retrieves showcase items strictly from this view, ensuring database isolation.

### B. High-Conversion Retailer Application Form
To maximize conversion, we eliminate high-friction questions (like annual revenue) and avoid locking the system into rigid hardware sizes.
*   **Fields Retained**:
    *   Business / Store Name
    *   Contact Person Name
    *   Professional Email & Phone Number
    *   Store Location (Full Address)
    *   Number of Locations (Stores)
    *   Store Type (Beauty Supply, Boutique, Pharmacy, Chain, etc.)
    *   Approximate Available Retail Space (Sq. Ft.)
    *   Display Support Interest (Yes / No / Not Sure)
    *   Preferred Display Format (Wall Display, Counter Display, Table Display, Not Sure) (Optional selection)
*   **Backend Storage**: Submissions write directly to a new `retailer_applications` table in Supabase.

### C. Bilingual Middleware Routing
*   **Routing Logic**: Root `/` redirects default to `/en`. If the browser's header language preference is set explicitly to Korean (`ko` or `ko-KR`), it redirects to `/ko`.
*   **Preference Persistence**: Once a user manually toggles the language switcher, their choice is saved in a cookie to override default routing on future visits.

---

## 3. Homepage Story Flow (Editorial Narrative)

The narrative follows a logical flow that builds commercial interest, details the program, introduces the strategy, and prompts an application.

```mermaid
graph TD
    A["Hero Section (K-Beauty Market Opportunity)"] --> B["The K Select Solution (Beyond Wholesale)"]
    B --> C["Assortment Strategy (The Sourcing Algorithm)"]
    C --> D["Display & Merchandising (Visual Support)"]
    D --> E["Curated Products Showcase (View-Only Gallery)"]
    E --> F["How It Works (Onboarding Path)"]
    F --> G["Company Credentials & Experience (Trust Builder)"]
    G --> H["Conversion CTA Footer"]
```

### Story Section Flow Details

#### 1. Hero Section (The Opportunity Hook)
*   *Story*: Establish K-Beauty as the fastest-growing revenue driver in retail. Highlight the simplicity of integrating it.
*   *Key Action*: Dual CTAs: `Apply for Partnership` and `Explore Products`.

#### 2. The K Select Solution (Beyond Wholesale)
*   *Story*: We don't just ship boxes. We partner with you to select, display, and merchandise products, eliminating inventory risks.

#### 3. Assortment Strategy (Curated for US Retail)
*   *Story*: Our data-driven assortment selects only the top-performing Korean brands matched to your store's regional demographics. Zero guesswork for the retailer.

#### 4. Display & Merchandising (Physical retail support)
*   *Story*: Introduce physical display systems (wall space, counter setups) and detailed planograms designed to increase sales velocity per square foot.

#### 5. Curated Products Showcase Preview
*   *Story*: Present 4–6 approved public K-Beauty products. Highlight consumer benefits (e.g. hydration, skin soothing) without revealing wholesale terms.

#### 6. How It Works (The 3-Step Path)
*   *Story*: 1) Apply online, 2) Verify account & get customized plans, 3) Set up displays & order through the Portal.

#### 7. Credibility & Capabilities (No Fake Testimonials)
*   *Story*: Focus on facts: K Select's extensive Korean supply network, U.S.-based warehousing/logistics operations, and retail merchandising track record.

#### 8. Final Conversion CTA
*   *Story*: Invitation to join. A streamlined email field to kick off the application.

---

## 4. Copywriting and Marketing Claim Guidelines

To ensure legal compliance and professional credibility in the U.S. market, the copywriting must adhere to the following naming conventions:

| Avoid (Risk of Over-promise) | Aligned Copy Alternative (Professional Sincerity) |
| :--- | :--- |
| `FDA compliance assurance` | `U.S. market readiness review / Compliant Sourcing` |
| `Logistics guarantees` | `U.S.-based logistics and warehousing support` |
| `Manufacturer-direct prices` | `Direct-from-brand partner wholesale pricing` |
| `High-margin revenue driver` | `Curated for retail margin potential` |
| `Increase AOV per square foot` | `Optimized for sales productivity per square foot` |
