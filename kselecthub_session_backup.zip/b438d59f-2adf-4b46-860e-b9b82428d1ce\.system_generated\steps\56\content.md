Title: K Select Network — K-Beauty Growth Program

Source: https://kselectnetwork.com

---

[K SELECT NETWORKCurated. Connected. Growing Together.](https://kselectnetwork.com/)
[KBGP](https://kselectnetwork.com/#program-two-phases)
- [About먼저 300개로 검증하고, 그 결과 위에서 확대합니다.](https://kselectnetwork.com/#program-two-phases)
- [Policy상권 보호 · First Order Protection](https://kselectnetwork.com/#policy)
- [Benefits중소 브랜드가 실제로 얻는 것](https://kselectnetwork.com/#benefits)
- [Process테스트 파트너십 → 본 파트너십](https://kselectnetwork.com/#process)
- [Eligibility참여 조건 6가지 · 자가진단](https://kselectnetwork.com/#eligibility)
[About먼저 300개로 검증하고, 그 결과 위에서 확대합니다.](https://kselectnetwork.com/#program-two-phases)
[Policy상권 보호 · First Order Protection](https://kselectnetwork.com/#policy)
[Benefits중소 브랜드가 실제로 얻는 것](https://kselectnetwork.com/#benefits)
[Process테스트 파트너십 → 본 파트너십](https://kselectnetwork.com/#process)
[Eligibility참여 조건 6가지 · 자가진단](https://kselectnetwork.com/#eligibility)
[Letusto](https://kselectnetwork.com/#letusto)
[FAQ](https://kselectnetwork.com/#faq)
[Export Voucher](https://kselectnetwork.com/export-voucher)
2026 코호트 접수중
KR/EN
[파트너쉽 신청하기](https://kselectnetwork.com/#eligibility)
- [About먼저 300개로 검증하고, 그 결과 위에서 확대합니다.](https://kselectnetwork.com/#program-two-phases)
- [Policy상권 보호 · First Order Protection](https://kselectnetwork.com/#policy)
- [Benefits중소 브랜드가 실제로 얻는 것](https://kselectnetwork.com/#benefits)
- [Process테스트 파트너십 → 본 파트너십](https://kselectnetwork.com/#process)
- [Eligibility참여 조건 6가지 · 자가진단](https://kselectnetwork.com/#eligibility)
[About먼저 300개로 검증하고, 그 결과 위에서 확대합니다.](https://kselectnetwork.com/#program-two-phases)
[Policy상권 보호 · First Order Protection](https://kselectnetwork.com/#policy)
[Benefits중소 브랜드가 실제로 얻는 것](https://kselectnetwork.com/#benefits)
[Process테스트 파트너십 → 본 파트너십](https://kselectnetwork.com/#process)
[Eligibility참여 조건 6가지 · 자가진단](https://kselectnetwork.com/#eligibility)
[Letusto](https://kselectnetwork.com/#letusto)
[FAQ](https://kselectnetwork.com/#faq)
[Export Voucher](https://kselectnetwork.com/export-voucher)
2026 코호트 접수중
K-Beauty Growth Program — Operated by Letusto Inc.

“우리 제품이 미국에서 통할까?” 이 질문에 추측이 아닌 데이터로 답해 드립니다. 오랜 기간 협력해 온 최대 7개 주 10곳의 리테일 매장에서 실제로 제품을 검증시키고, 세계 최대 온라인 플랫폼인 US Amazon에 동시 런칭됩니다. 매대와 아마존의 실제 판매 데이터와 고객 반응을 함께 확보해, 다음 액션 플랜을 감이 아닌 근거로 설계합니다.
[파트너십 신청하기](https://kselectnetwork.com/#eligibility)
[프로그램 살펴보기 ↗](https://kselectnetwork.com#program-two-phases)
BEAUTY SUPPLY 파트너 네트워크

10개 스토어 · 7개 주
STORE-IN-A-STORE 모델
현지 뷰티 전문 매장 내 검증된 공간 확보
ONLINE LAUNCH
세계 최대 온라인 플랫폼Amazon 동시 런칭
Why Letusto

20년 이상의 리테일·이커머스 경험을 바탕으로 제품 발굴, 시장 검증, 브랜딩, Amazon 판매와 오프라인 유통까지 직접 실행합니다.
자체 개발한 시장 분석 프로그램 LENS를 활용해 데이터를 실제 런칭과 운영 의사결정에 연결합니다.
By the Numbers

Program — Two Phases

Phase 01
Test

### 테스트 입점
제품별로 오프라인 10개 파트너 매장 테스트 판매용 약 240개와 Amazon 판매·고객 반응 검증용 약 60개를 기준으로 시작합니다.
Phase 02
Partnership

### 본 파트너십
테스트 실판매 데이터를 근거로 진열 규모와 채널을 확대합니다. 상권 보호 정책 아래 유통을 정리합니다.
Policy — 04

## 두려움에는 정책으로 답합니다.
선금을 보낸 뒤 연락이 끊긴다
병행수입으로 가격이 무너진다
현지 매장과 연결될 방법이 없다
실제 판매량을 알 수 없다
Benefits

## 브랜드 파트너사에 제공하는 실질적 가치
추상적인 가능성이 아닌, 미국 시장에서 직접 실행하고 검증할 수 있는 성장 구조를 제공합니다.
- 01현지 영업조직 없이 미국 오프라인 시장 진출
- 02소량 테스트로 초기 재고와 실패 위험 최소화
- 03매장별·SKU별 실제 판매 데이터 확보
- 04Store-in-a-Store를 통한 전용 매대와 소비자 접점 확보
- 05판매 성과에 따른 반복 발주와 입점 매장 확대
- 06미국 시장에 맞춘 가격·패키지·포지셔닝 개선
- 07확대·개선·중단을 결정할 객관적 근거 확보
- 08오프라인·Amazon 동시 런칭과 실제 구매자 리뷰 확보를 통한 시장 반응 검증30+
현지 영업조직 없이 미국 오프라인 시장 진출
소량 테스트로 초기 재고와 실패 위험 최소화
매장별·SKU별 실제 판매 데이터 확보
Store-in-a-Store를 통한 전용 매대와 소비자 접점 확보
판매 성과에 따른 반복 발주와 입점 매장 확대
미국 시장에 맞춘 가격·패키지·포지셔닝 개선
확대·개선·중단을 결정할 객관적 근거 확보
오프라인·Amazon 동시 런칭과 실제 구매자 리뷰 확보를 통한 시장 반응 검증
The Honest Part

10개 매장과 온라인에서 300개를 실제로 판매하면, 가격 저항과 리뷰 반응, 재구매율이 데이터로 남습니다. 그 데이터가 “아직 아니다”라고 말할 때 우리는 그대로 전달합니다. 무엇을 고쳐야 하는지, 어느 시점에 다시 시작해야 하는지까지 함께 정리해 드립니다.
대량 생산과 마케팅 비용을 쏟은 뒤에 아는 것과, 300개로 미리 아는 것의 차이가 이 프로그램의 실질적인 가치입니다.
판매를 권하는 파트너는 많습니다. 판매를 미루라고 말할 수 있는 파트너는 드뭅니다.
Process — 06

신청서 제출 및 기본 서류 검토
Brand
신청서 제출 · 회사 및 제품 정보 · 상표권 및 기존 판매 채널 정보 제공
Letusto
기본 준비 조건 및 서류 검토
Duration
즉시
- 01신청 접수−Phase 01 — Test신청서 제출 및 기본 서류 검토Brand신청서 제출 · 회사 및 제품 정보 · 상표권 및 기존 판매 채널 정보 제공Letusto기본 준비 조건 및 서류 검토Duration즉시
- 02상품 · 규격 검토+
- 03담당자 미팅+
- 04분석 및 테스트 계약+
- 05테스트 런칭 및 데이터 리뷰+
- 06본 파트너십+
신청서 제출 및 기본 서류 검토
Brand
신청서 제출 · 회사 및 제품 정보 · 상표권 및 기존 판매 채널 정보 제공
Letusto
기본 준비 조건 및 서류 검토
Duration
즉시
Sourcing — Category Mix

## KBGP 소싱 포트폴리오
2025년 미국 K-Beauty 시장 $27.6B, 대미 수출 $2.2B, 글로벌 점유율 23.4%. 스킨케어가 시장의 68.7%를 차지합니다. CAGR 9.5% (2026–2033).
- K-스킨케어60%
- K-헤어케어10%
- K-메이크업10%
- K-바디케어10%
- K-퍼스널케어5%
- K-뷰티툴5%
대표 품목 — K-스킨케어
클렌징, 토너/미스트, 에센스/세럼/앰플, 모이스처라이저, 선케어, 마스크/패치, 아이/립 케어
위 비율은 초기 소싱 포트폴리오의 목표 구성으로, 시장 반응과 파트너 매장 수요에 따라 조정될 수 있습니다. 위 카테고리에 명시적으로 해당하지 않더라도, 반복 구매를 이끌어낼 수 있는 상품이라면 별도로 검토 가능합니다.
대표 품목 — K-스킨케어
클렌징, 토너/미스트, 에센스/세럼/앰플, 모이스처라이저, 선케어, 마스크/패치, 아이/립 케어
위 비율은 초기 소싱 포트폴리오의 목표 구성으로, 시장 반응과 파트너 매장 수요에 따라 조정될 수 있습니다. 위 카테고리에 명시적으로 해당하지 않더라도, 반복 구매를 이끌어낼 수 있는 상품이라면 별도로 검토 가능합니다.
Eligibility — Self Check

## 프로그램 참여를 위한 준비 사항을 확인해 주세요.
한국에서 제품을 생산하는 제조업체, 자체 브랜드를 운영하는 브랜드사, 또는 해당 브랜드의 정식·독점 공급 권한을 보유한 유통업체가 신청할 수 있습니다. 기본 준비 조건과 제품 적합성을 검토한 후 참여 여부를 결정합니다.
아래 항목은 K-Beauty Growth Program을 원활하게 진행하기 위한 기본 준비 사항입니다. 현재 모든 준비가 완료되지 않았더라도, 향후 보완 및 협력이 가능한 경우 프로그램 참여를 함께 검토할 수 있습니다.
항목 확인 완료
6개 준비 사항을 모두 확인하시면 파트너십 신청이 가능합니다.
- 01안정적인 제품 공급현재 판매 중이거나 출시를 준비 중인 제품으로, 테스트 이후에도 안정적인 생산과 지속적인 공급이 가능합니다.진행 가능협의 필요
- 02미국 시장 규정 대응미국 진출에 필요한 성분, 인증, 등록, 라벨링 및 통관 요건을 확인하고 필요한 보완 절차에 협력할 수 있습니다.진행 가능협의 필요
- 03초기 테스트 물량 공급온·오프라인 실제 판매 테스트를 위한 제품별 약 300개의 초기 물량을 공급할 수 있습니다.진행 가능협의 필요
- 04북미 유통 권한 협의기존 북미 유통 계약과 판매 채널의 충돌 여부를 확인할 수 있어야 하며, 테스트 결과와 협력 조건이 충족될 경우 Letusto 채널의 안정적인 공급과 북미 유통 권한을 상호 협의할 수 있습니다.진행 가능협의 필요
- 05공동 마케팅 참여시장 테스트 이후 본격적인 판매 확대를 위해, 상호 협의된 기간과 범위 내에서 마케팅 활동에 참여할 의향이 있습니다.진행 가능협의 필요
- 06판매 콘텐츠 협력제품 이미지, 영상, 사용 방법, 상세 정보 등 판매에 필요한 콘텐츠를 제공하거나 제작에 협력할 수 있습니다.진행 가능협의 필요

#### 안정적인 제품 공급
현재 판매 중이거나 출시를 준비 중인 제품으로, 테스트 이후에도 안정적인 생산과 지속적인 공급이 가능합니다.

#### 미국 시장 규정 대응
미국 진출에 필요한 성분, 인증, 등록, 라벨링 및 통관 요건을 확인하고 필요한 보완 절차에 협력할 수 있습니다.

#### 초기 테스트 물량 공급
온·오프라인 실제 판매 테스트를 위한 제품별 약 300개의 초기 물량을 공급할 수 있습니다.

#### 북미 유통 권한 협의
기존 북미 유통 계약과 판매 채널의 충돌 여부를 확인할 수 있어야 하며, 테스트 결과와 협력 조건이 충족될 경우 Letusto 채널의 안정적인 공급과 북미 유통 권한을 상호 협의할 수 있습니다.

#### 공동 마케팅 참여
시장 테스트 이후 본격적인 판매 확대를 위해, 상호 협의된 기간과 범위 내에서 마케팅 활동에 참여할 의향이 있습니다.

#### 판매 콘텐츠 협력
제품 이미지, 영상, 사용 방법, 상세 정보 등 판매에 필요한 콘텐츠를 제공하거나 제작에 협력할 수 있습니다.
Apply — K-Beauty Growth Program

## 파트너 신청서
※ 추후 파트너 포털(Brand SaaS) 계정 오픈 시 본인 확인 검증 도구로 사용되니 정확히 입력해 주십시오.
※ 추후 파트너 포털(Brand SaaS) 계정 로그인 및 본인 확인 검증 도구로 사용됩니다.
01
제품 이미지 · 성분표 · 소개자료 · 최대 3개 · jpg · png · webp · pdf · 개당 10MB · 전체 합계 10MB
전체 첨부 0MB / 10MB
💡 중요 안내
신청서에 입력하신 사업자등록번호와 이메일 주소는 추후 파트너사 전용 포털(Brand SaaS 포털 계정 오픈)의 가입 및 검증 도구로 사용되오니 잘 기억해 주시기 바랍니다.
첨부 0MB / 10MB
전송이 어려우시면 contact@letusto.com 으로 직접 보내 주셔도 됩니다.
FAQ

## 자주 묻는 질문
Category
답변에서 다루지 않은 사항은 [contact@letusto.com](mailto:contact@letusto.com)으로 문의해 주십시오.
Category
답변에서 다루지 않은 사항은 [contact@letusto.com](mailto:contact@letusto.com)으로 문의해 주십시오.

한국 내 제조업체 또는 유통업체라면 대부분 신청 가능합니다. 매출 규모에 대한 별도 제한은 없으나, 자체 브랜드를 보유했거나 해당 브랜드의 독점 유통권을 보유하고 있어야 합니다. 타사 브랜드를 단순 재판매하는 경우에는 병행수입 관련 확인 절차가 추가로 진행됩니다.
① 온라인 신청서 제출 → ② 서류·제품 정보 1차 검토 → ③ 1차 미팅 → ④ 필요 시 보완자료 요청 → ⑤ 분석자료 공유 및 2차 미팅 → ⑥ 최종 심사 및 계약 순으로 진행됩니다. 서류가 완비된 경우 통상 2~4주 내외 소요됩니다.
제품 상세 정보(특징, 기능, 성분표·사양서), 상표 등록 여부 확인 자료, 공급 조건(공급가), 패키지 정보(개별상품 배송 시 무게와 부피), 카톤박스 정보, 상품 URL(기존 국내 및 해외 판매 현황, 있는 경우)이 기본적으로 필요합니다. 화장품 외 카테고리(선크림, 여드름 케어 등)는 성분표와 라벨·광고에 사용 중인 효능 주장 문구도 함께 제출해야 정확한 검토가 가능합니다.
미국에서 판매가 제한된 성분이 포함된 경우, 규제 요건 충족이 현실적으로 어려운 경우, 동일 브랜드의 미국 독점 유통 계약이 이미 타사와 체결되어 있는 경우가 대표적입니다.
가능합니다. 다만 기존 병행수입 채널과의 가격 정책 충돌 여부, 독점권 존재 여부를 먼저 확인해야 하며, 필요한 경우 기존 유통사와의 관계 정리 방안이나 채널 분리 전략을 함께 상의드립니다.
가능합니다. 전체 라인업을 한 번에 제출하지 않아도 되며, 대표 제품 1~2개로 먼저 테스트를 진행한 뒤 반응을 보고 라인업을 확장하는 방식을 권장합니다.
* 본 FAQ는 초안이며, 수수료·최소 물량 등 계약별로 달라질 수 있는 수치성 항목은 게시 전 실제 계약 조건에 맞춰 확인·수정이 필요합니다.
Apply — K-Beauty Growth Program

제품은 브랜드가 만듭니다. 미국 시장은 함께 만듭니다.
자가진단 6문항은 3분이면 끝납니다. 조건을 충족하면 바로 신청서로 연결됩니다.
[자가진단 시작](https://kselectnetwork.com/#eligibility)
[미팅 예약](mailto:contact@letusto.com?subject=K-Beauty%20Growth%20Program%20%EB%AF%B8%ED%8C%85%20%EC%98%88%EC%95%BD%20%EB%AC%B8%EC%9D%98)
Letusto Inc. · [contact@letusto.com](mailto:contact@letusto.com) · 856-383-8288
Operated by Letusto Inc.
Program
[프로그램 개요](https://kselectnetwork.com/#program-two-phases)
[정책](https://kselectnetwork.com/#policy)
[혜택](https://kselectnetwork.com/#benefits)
[절차](https://kselectnetwork.com/#process)
Apply
[참여 자격](https://kselectnetwork.com/#eligibility)
[자가진단 · 신청](https://kselectnetwork.com/#eligibility)
[미팅 예약](mailto:contact@letusto.com?subject=K-Beauty%20Growth%20Program%20%EB%AF%B8%ED%8C%85%20%EC%98%88%EC%95%BD%20%EB%AC%B8%EC%9D%98)
정부지원사업
[수출바우처](https://kselectnetwork.com/export-voucher)
[지원금 계산기](https://kselectnetwork.com/export-voucher#voucher-calculator)
[해외지사화](https://kselectnetwork.com/export-voucher#voucher-branch)
Contact
[contact@letusto.com](mailto:contact@letusto.com)
856-383-8288
K-Beauty Growth Program · K Select Network · Letusto Inc.
© Letusto Inc. · 개인정보처리방침

